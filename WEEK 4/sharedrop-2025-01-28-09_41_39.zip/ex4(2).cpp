#include <iostream>
#include <vector>
using namespace std;

void topologicalSortSourceRemoval(int adj[][5], int n) {
    vector<int> inDegree(n, 0);
    for (int i = 0; i < n; i++) {
        for (int j = 0; j < n; j++) {
            if (adj[i][j] == 1) {
                inDegree[j]++;
            }
        }
    }
    vector<int> result;
    while (result.size() < n) {
        for (int i = 0; i < n; i++) {
            if (inDegree[i] == 0) {
                result.push_back(i);
                inDegree[i] = -1;
                for (int j = 0; j < n; j++) {
                    if (adj[i][j] == 1) {
                        inDegree[j]--;
                    }
                }
                break;
            }
        }
    }
    for (int i = 0; i < n; i++) {
        cout << result[i] << " ";
    }
}

int main() {
    int adj[5][5] = {
        {0, 1, 1, 0, 0},
        {0, 0, 0, 1, 0},
        {0, 0, 0, 1, 1},
        {0, 0, 0, 0, 1},
        {0, 0, 0, 0, 0}
    };
    topologicalSortSourceRemoval(adj, 5);
    return 0;
}
