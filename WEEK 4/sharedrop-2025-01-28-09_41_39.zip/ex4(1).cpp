#include <iostream>
using namespace std;

void dfs(int v, bool visited[], int adj[][5], int n, int result[], int &index) {
    visited[v] = true;
    for (int i = 0; i < n; i++) {
        if (adj[v][i] == 1 && !visited[i]) {
            dfs(i, visited, adj, n, result, index);
        }
    }
    result[index--] = v;
}

void topologicalSort(int adj[][5], int n) {
	
    bool visited[5] = {false};
    int result[5];
    int index = n - 1;
    for (int i = 0; i < n; i++) {
        if (!visited[i]) {
            dfs(i, visited, adj, n, result, index);
        }
    }
    for (int i = 0; i < n; i++) {
        cout << result[i] << " ";
    }
}

int main() {
    int adj[5][5] = {
        {0, 1, 1, 0, 0},
        {0, 0, 0, 1, 0},
        {0, 0, 0, 1, 1},
        {0, 0, 0, 0, 1},
        {0, 0, 0, 0, 0}
    };
    topologicalSort(adj, 5);
    return 0;
}
